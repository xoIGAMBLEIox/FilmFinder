package com.filmfinder.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 10;
    private static final int REQ_GALLERY = 11;
    private ImageView preview;
    private TextView result;
    private ProgressBar progress;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(24,18,24,18); return t;
    }

    private Button button(String s) { Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b; }

    private void showHome() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,40,24,24);
        TextView title = text("FilmFinder", 30); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub = text("Identify a film or TV series from an image", 18); sub.setGravity(Gravity.CENTER); root.addView(sub);
        preview = new ImageView(this); preview.setAdjustViewBounds(true); preview.setMinimumHeight(300); root.addView(preview, new LinearLayout.LayoutParams(-1,0,1));
        Button camera = button("Take a photo"); Button gallery = button("Choose from gallery");
        root.addView(camera); root.addView(gallery);
        progress = new ProgressBar(this); progress.setVisibility(View.GONE); root.addView(progress);
        result = text("", 18); root.addView(result);
        camera.setOnClickListener(v -> takePhoto()); gallery.setOnClickListener(v -> choosePhoto());
        setContentView(root);
    }

    private void takePhoto() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA); return; }
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); startActivityForResult(i, REQ_CAMERA);
    }

    private void choosePhoto() { startActivityForResult(new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), REQ_GALLERY); }

    @Override protected void onActivityResult(int req, int code, Intent data) {
        super.onActivityResult(req, code, data); if (code != RESULT_OK || data == null) return;
        Bitmap bmp = null;
        try {
            if (req == REQ_CAMERA && data.getExtras() != null) bmp = (Bitmap)data.getExtras().get("data");
            else if (req == REQ_GALLERY && data.getData() != null) bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), data.getData());
        } catch (Exception ignored) {}
        if (bmp != null) { preview.setImageBitmap(bmp); identify(bmp); }
    }

    private void identify(Bitmap bmp) {
        progress.setVisibility(View.VISIBLE); result.setText("Looking for the film…");
        // Deliberately local placeholder: a production build must send the image to a secure backend
        // that performs vision recognition and then queries a movie/TV database.
        preview.postDelayed(() -> { progress.setVisibility(View.GONE); result.setText("Demo build: image captured successfully.\n\nTo enable real identification, connect the app to the FilmFinder recognition backend (see README)."); }, 700);
    }
}
