plugins { id("com.android.application") }

android { namespace = "com.filmfinder.app"; compileSdk = 36
    defaultConfig { applicationId = "com.filmfinder.app"; minSdk = 23; targetSdk = 36; versionCode = 1; versionName = "1.0" }
}
