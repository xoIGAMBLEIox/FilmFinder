# FilmFinder

Android 36 starter project for an app that lets a user take or choose an image and identify a film/TV series.

## Important
This project is intentionally honest about the recognition layer: the UI and image capture work, but the demo does **not** pretend to identify films. A production version needs a secure backend for image recognition and a movie/TV metadata provider. Never ship a secret AI or database API key inside the APK.

## Build in the cloud from a phone
The included GitHub Actions workflow builds `app-debug.apk` automatically. Create a GitHub repository, upload this folder, then run the workflow from the Actions tab. The APK appears as a downloadable workflow artifact.

## Local build requirements
- JDK 17
- Gradle 9.6
- Android SDK Platform 36
- Android SDK Build Tools 36.0.0
- Android Gradle Plugin 9.4.0

These versions match the current AGP 9.4 compatibility requirements.
